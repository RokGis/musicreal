@TestOn('browser')
library;

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_auth_platform_interface/firebase_auth_platform_interface.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_core_platform_interface/firebase_core_platform_interface.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:project_for_management/auth/firebase_auth/google_auth.dart';
import '../mantas/support/fake_auth.dart';

class WebCore extends FirebasePlatform {
  final instance = FirebaseAppPlatform(
      '[DEFAULT]',
      const FirebaseOptions(
          apiKey: 'test-key',
          appId: 'test-app',
          messagingSenderId: 'test-sender',
          projectId: 'test-project'));
  @override
  FirebaseAppPlatform app([String name = '[DEFAULT]']) => instance;
  @override
  List<FirebaseAppPlatform> get apps => [instance];
}

class WebAuth extends FakeFirebaseAuth {
  int popupCalls = 0;
  AuthProvider? provider;
  Object? popupError;
  @override
  Future<UserCredentialPlatform> signInWithPopup(
      AuthProvider authProvider) async {
    popupCalls++;
    provider = authProvider;
    if (popupError != null) throw popupError!;
    final credential = GoogleAuthProvider.credential(idToken: 'test-id-token');
    return FakeUserCredential(this,
        FakeUser(this, const FakeIdentity(uid: 'ld2-edas-web')), credential);
  }
}

void main() {
  final auth = WebAuth();
  setUpAll(() {
    FirebasePlatform.instance = WebCore();
    FirebaseAuthPlatform.instance = auth;
  });
  setUp(() {
    auth.reset();
    auth.popupCalls = 0;
    auth.provider = null;
    auth.popupError = null;
  });

  test('G07 web uses Google popup and returns its user', () async {
    expect(kIsWeb, isTrue);
    final result = await googleSignInFunc();
    expect(result?.user?.uid, 'ld2-edas-web');
    expect(auth.popupCalls, 1);
    expect(auth.provider, isA<GoogleAuthProvider>());
    expect(auth.receivedCredentials, isEmpty);
  });
  for (final entry
      in {'G08': 'popup-closed-by-user', 'G09': 'popup-blocked'}.entries) {
    test('${entry.key} web ${entry.value} propagates to caller', () async {
      auth.popupError = FirebaseAuthException(
          code: entry.value, message: 'Popup unavailable');
      await expectLater(googleSignInFunc(), throwsA(same(auth.popupError)));
      expect(auth.popupCalls, 1);
      expect(auth.receivedCredentials, isEmpty);
    });
  }
}
