import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:project_for_management/auth/firebase_auth/google_auth.dart';
import 'support.dart';
import 'coverage_probe.dart';

void main() {
  setUpAll(setUpEdas);
  setUp(resetEdas);
  tearDownAll(EdasProbe.report);

  testWidgets('G01 successful Google credential reaches Firebase',
      (tester) async {
    googleSuccess();
    final result = await tester.runAsync(googleSignInFunc);
    expect(result?.user?.uid, edasUid);
    final credential = edasAuth.receivedCredentials.single as OAuthCredential;
    expect(credential.providerId, 'google.com');
    expect(credential.idToken, 'google-id-token-for-$edasEmail');
    expect(credential.accessToken, 'google-access-token');
    expect(edasGoogle.signOutCalls, 1);
    expect(edasGoogle.signInCalls, 1);
    expect(fakeFirestore.writeLog, isEmpty,
        reason: 'Google helper does not create a profile itself');
  });

  testWidgets('G02 cancelled account picker returns null', (tester) async {
    edasGoogle.signInError = FakeGoogleSignIn.userCancelled;
    final result = await tester.runAsync(googleSignInFunc);
    expect(result, isNull);
    expect(edasAuth.receivedCredentials, isEmpty);
    expect(edasAuth.currentUser, isNull);
  });

  testWidgets('G03 empty account result returns null', (tester) async {
    final result = await tester.runAsync(googleSignInFunc);
    expect(result, isNull);
    expect(edasGoogle.signInCalls, 1);
    expect(edasAuth.receivedCredentials, isEmpty);
  });

  testWidgets('G04 failure signing out does not block new sign in',
      (tester) async {
    googleSuccess();
    edasGoogle.signOutError = PlatformException(code: 'sign_out_failed');
    final result = await tester.runAsync(googleSignInFunc);
    expect(result?.user?.uid, edasUid);
    expect(edasGoogle.signInCalls, 1);
    expect(edasAuth.receivedCredentials, hasLength(1));
  });

  testWidgets('G05 Google SDK failure propagates unchanged', (tester) async {
    edasGoogle.signInError = networkFailure;
    await tester.runAsync(() =>
        expectLater(googleSignInFunc(), throwsA(same(edasGoogle.signInError))));
    expect(edasAuth.receivedCredentials, isEmpty);
  });

  testWidgets('G06 Firebase credential rejection propagates unchanged',
      (tester) async {
    googleSuccess();
    edasAuth.nextError = FirebaseAuthException(code: 'invalid-credential');
    await tester.runAsync(() =>
        expectLater(googleSignInFunc(), throwsA(same(edasAuth.nextError))));
    expect(edasAuth.currentUser, isNull);
    expect(edasAuth.receivedCredentials, hasLength(1));
  });
}
