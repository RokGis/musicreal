import 'dart:convert';

class EdasProbe {
  static final Map<String, int> statements = {};
  static final Map<String, Map<String, int>> decisions = {};
  static final Map<String, int> arms = {};
  static void statement(String id) => statements.update(id, (n) => n + 1, ifAbsent: () => 1);
  static bool condition(String id, bool value) {
    final counts = decisions.putIfAbsent(id, () => {'true': 0, 'false': 0});
    counts['$value'] = counts['$value']! + 1;
    return value;
  }
  static T arm<T>(String id, T value) {
    arms.update(id, (n) => n + 1, ifAbsent: () => 1);
    return value;
  }
  static void report() => print('EDAS_PROBE=${jsonEncode({
    'statements': statements, 'decisions': decisions, 'arms': arms})}');
}
