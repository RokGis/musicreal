import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:project_for_management/pages/log_in_page/log_in_page_widget.dart';
import 'package:project_for_management/pages/profile/profile_widget.dart';
import 'support.dart';
import 'coverage_probe.dart';

void main() {
  setUpAll(setUpEdas);
  setUp(resetEdas);
  tearDownAll(EdasProbe.report);
  testWidgets('I01 Google sign in creates profile visible in real profile page',
      (tester) async {
    googleSuccess();
    await pumpRoutedPage(tester,
        name: LogInPageWidget.routeName,
        path: LogInPageWidget.routePath,
        page: (_) => const LogInPageWidget());
    await tester.runAsync(() async {
      await tester.tap(find.text('Continue with Google'));
      await Future<void>.delayed(const Duration(milliseconds: 200));
    });
    await settle(tester);
    expect(find.text(routeMarker('Home')), findsOneWidget);
    expect(fakeFirestore.docsIn('users'), ['users/$edasUid']);
    await pumpRoutedPage(tester,
        name: ProfileWidget.routeName,
        path: ProfileWidget.routePath,
        page: (_) => const ProfileWidget());
    expect(find.text(edasName), findsOneWidget);
    expect(find.text(edasEmail), findsOneWidget);
    expect(find.byType(EditableText), findsNothing);
  });
}
