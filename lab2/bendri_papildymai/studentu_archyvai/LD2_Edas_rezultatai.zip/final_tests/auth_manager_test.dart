import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:project_for_management/auth/firebase_auth/auth_util.dart';
import 'support.dart';
import 'coverage_probe.dart';

void main() {
  setUpAll(setUpEdas);
  setUp(resetEdas);
  tearDownAll(EdasProbe.report);

  testWidgets('M01 first sign in creates profile and returns user',
      (tester) async {
    googleSuccess();
    final context = await openContext(tester);
    final user = await tester
        .runAsync(() => FirebaseAuthManager().signInWithGoogle(context));
    expect(user?.loggedIn, isTrue);
    expect(user?.uid, edasUid);
    expect(fakeFirestore.docsIn('users'), ['users/$edasUid']);
    final profile = fakeFirestore.data('users/$edasUid')!;
    expect(profile['uid'], edasUid);
    expect(profile['email'], edasEmail);
    expect(profile['display_name'], edasName);
    expect(currentUserDocument?.uid, edasUid);
  });

  testWidgets('M02 existing profile is preserved', (tester) async {
    googleSuccess();
    fakeFirestore.seed('users/$edasUid',
        {'uid': edasUid, 'display_name': 'Existing name', 'streak_count': 7});
    final context = await openContext(tester);
    final user = await tester
        .runAsync(() => FirebaseAuthManager().signInWithGoogle(context));
    expect(user?.uid, edasUid);
    expect(fakeFirestore.writeLog, isEmpty);
    expect(fakeFirestore.data('users/$edasUid')!['streak_count'], 7);
    expect(currentUserDocument?.displayName, 'Existing name');
  });

  testWidgets('M03 cancellation returns null without creating profile',
      (tester) async {
    edasGoogle.signInError = FakeGoogleSignIn.userCancelled;
    final context = await openContext(tester);
    final user = await tester
        .runAsync(() => FirebaseAuthManager().signInWithGoogle(context));
    expect(user, isNull);
    expect(fakeFirestore.docsIn('users'), isEmpty);
    expect(currentUserDocument, isNull);
  });

  testWidgets('M04 credential without user creates no profile', (tester) async {
    googleSuccess();
    edasAuth.returnNullUser = true;
    final context = await openContext(tester);
    final user = await tester
        .runAsync(() => FirebaseAuthManager().signInWithGoogle(context));
    expect(user, isNotNull);
    expect(user!.loggedIn, isFalse);
    expect(fakeFirestore.writeLog, isEmpty);
    expect(currentUserDocument, isNull);
  });

  const messages = {
    'email-already-in-use':
        'Error: The email is already in use by a different account',
    'INVALID_LOGIN_CREDENTIALS':
        'Error: The supplied auth credential is incorrect, malformed or has expired',
    'invalid-credential': 'Error: Rejected by Firebase',
  };
  var number = 5;
  for (final entry in messages.entries) {
    final id = 'M${number.toString().padLeft(2, '0')}';
    number++;
    testWidgets('$id ${entry.key} shows expected message', (tester) async {
      googleSuccess();
      edasAuth.nextError = FirebaseAuthException(
          code: entry.key, message: 'Rejected by Firebase');
      final context = await openContext(tester);
      final user = await tester
          .runAsync(() => FirebaseAuthManager().signInWithGoogle(context));
      await settle(tester);
      expect(user, isNull);
      expect(find.text(entry.value), findsOneWidget);
      expect(fakeFirestore.writeLog, isEmpty);
      expect(edasAuth.currentUser, isNull);
    });
  }

  testWidgets('M08 missing optional identity data still creates profile',
      (tester) async {
    googleSuccess();
    edasAuth.nextIdentity = const FakeIdentity(uid: edasUid);
    final context = await openContext(tester);
    final user = await tester
        .runAsync(() => FirebaseAuthManager().signInWithGoogle(context));
    expect(user?.uid, edasUid);
    final profile = fakeFirestore.data('users/$edasUid')!;
    expect(profile['uid'], edasUid);
    expect(profile['email'] ?? '', isEmpty);
    expect(profile['display_name'] ?? '', isEmpty);
  });
}
