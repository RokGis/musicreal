// Requirement-based tests kept separate: these intentionally expose existing defects.
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:project_for_management/auth/firebase_auth/firebase_auth_manager.dart';
import 'support.dart';

void main() {
  setUpAll(setUpEdas);
  setUp(resetEdas);
  testWidgets('R01 SCRUM-30 AC6 cancellation should show a message',
      (tester) async {
    edasGoogle.signInError = FakeGoogleSignIn.userCancelled;
    final context = await openContext(tester);
    final result = await tester
        .runAsync(() => FirebaseAuthManager().signInWithGoogle(context));
    await settle(tester);
    expect(result, isNull);
    expect(find.byType(SnackBar), findsOneWidget);
  });

  testWidgets('R02 SCRUM-30 AC6 SDK failure should be handled and shown',
      (tester) async {
    edasGoogle.signInError = networkFailure;
    final context = await openContext(tester);
    final result = await tester
        .runAsync(() => FirebaseAuthManager().signInWithGoogle(context));
    await settle(tester);
    expect(result, isNull);
    expect(find.byType(SnackBar), findsOneWidget);
  });

  testWidgets('R03 null Firebase message should still show a safe error',
      (tester) async {
    googleSuccess();
    edasAuth.nextError = FirebaseAuthException(code: 'network-request-failed');
    final context = await openContext(tester);
    final result = await tester
        .runAsync(() => FirebaseAuthManager().signInWithGoogle(context));
    await settle(tester);
    expect(result, isNull);
    expect(find.byType(SnackBar), findsOneWidget);
  });

  testWidgets('R04 profile write failure should be handled and shown',
      (tester) async {
    googleSuccess();
    fakeFirestore.failWritesWith =
        FirebaseException(plugin: 'cloud_firestore', code: 'permission-denied');
    final context = await openContext(tester);
    final result = await tester
        .runAsync(() => FirebaseAuthManager().signInWithGoogle(context));
    await settle(tester);
    expect(result, isNull);
    expect(find.byType(SnackBar), findsOneWidget);
  });
}
