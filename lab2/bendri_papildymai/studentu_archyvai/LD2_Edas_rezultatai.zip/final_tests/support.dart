import 'package:firebase_auth_platform_interface/firebase_auth_platform_interface.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:google_sign_in_platform_interface/google_sign_in_platform_interface.dart';
import '../mantas/support/test_env.dart';

export '../mantas/support/test_env.dart';

const edasUid = 'ld2-edas-user';
const edasEmail = 'edas@example.test';
const edasName = 'Edas Testas';
final edasAuth = EdasAuth();
final edasGoogle = EdasGoogle();

class EdasAuth extends FakeFirebaseAuth {
  bool returnNullUser = false;
  @override
  void reset() {
    super.reset();
    returnNullUser = false;
  }

  @override
  Future<UserCredentialPlatform> signInWithCredential(
      AuthCredential credential) {
    if (returnNullUser) {
      receivedCredentials.add(credential);
      return Future.value(EmptyUserCredential(this));
    }
    return super.signInWithCredential(credential);
  }
}

class EmptyUserCredential extends UserCredentialPlatform {
  EmptyUserCredential(FirebaseAuthPlatform auth) : super(auth: auth);
}

class EdasGoogle extends FakeGoogleSignIn {
  int signOutCalls = 0;
  Object? signOutError;
  @override
  void reset() {
    super.reset();
    signOutCalls = 0;
    signOutError = null;
  }

  @override
  Future<void> signOut() async {
    signOutCalls++;
    if (signOutError != null) throw signOutError!;
  }
}

Future<void> setUpEdas() async {
  await setUpMusicRealTestEnv();
  FirebaseAuthPlatform.instance = edasAuth;
  GoogleSignInPlatform.instance = edasGoogle;
}

void resetEdas() {
  resetMusicRealTestEnv();
  edasAuth.reset();
  edasGoogle.reset();
}

void googleSuccess() {
  edasGoogle.nextAccount = GoogleSignInUserData(
      email: edasEmail, id: 'ld2-google-account', displayName: edasName);
  edasAuth.nextIdentity =
      const FakeIdentity(uid: edasUid, email: edasEmail, displayName: edasName);
}

Future<BuildContext> openContext(WidgetTester tester) async {
  late BuildContext context;
  await tester
      .pumpWidget(MaterialApp(home: Scaffold(body: Builder(builder: (value) {
    context = value;
    return const SizedBox();
  }))));
  return context;
}

PlatformException get networkFailure =>
    PlatformException(code: 'network_error', message: 'Offline');
