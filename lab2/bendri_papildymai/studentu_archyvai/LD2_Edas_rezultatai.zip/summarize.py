import json, pathlib, re, html
root = pathlib.Path(__file__).resolve().parent
report = json.loads((root/'metrics.json').read_text(encoding='utf-8-sig'))
names = ['googleSignInFunc', 'FirebaseAuthManager._signInOrCreateAccount']
functions = {n:(r,f) for r in report['records'] for n,f in r['functions'].items() if n in names}
cognitive = {x['name']:x['score'] for filename in ['cognitive_google.json','cognitive_manager.json'] for x in json.loads((root/filename).read_text(encoding='utf-8-sig'))}

def lcov(filename, path, start, end):
    data=(root/filename).read_text(encoding='utf-8-sig')
    for record in data.split('end_of_record'):
        if not any(x.startswith('SF:') and x[3:].strip().replace('\\','/').endswith(path.replace('\\','/')) for x in record.splitlines()): continue
        lines=[]; branches=[]
        for x in record.splitlines():
            if x.startswith('DA:'):
                line,count=x[3:].split(',')[:2]
                if start<=int(line)<=end: lines.append((int(line),int(count)))
            if x.startswith('BRDA:'):
                line,block,branch,count=x[5:].split(',')
                if start<=int(line)<=end: branches.append((int(line),count))
        return {'lines':[sum(c>0 for _,c in lines),len(lines)],'vm_branches':[sum(c not in ['0','-'] for _,c in branches),len(branches)],'uncovered_lines':[n for n,c in lines if c==0]}
    return None

counts={'statements':{},'decisions':{},'arms':{}}
for line in (root/'probe_tests.log').read_text(encoding='utf-8-sig').splitlines():
    if 'EDAS_PROBE=' not in line: continue
    value=json.loads(line.split('EDAS_PROBE=',1)[1])
    for kind in ['statements','arms']:
        for key,n in value[kind].items(): counts[kind][key]=counts[kind].get(key,0)+n
    for key,values in value['decisions'].items():
        dest=counts['decisions'].setdefault(key,{'true':0,'false':0})
        for outcome,n in values.items(): dest[outcome]+=n
result={}
for name,(record,fn) in functions.items():
    short=name.split('.')[-1]
    entries=json.loads((root/('google_map.json' if short=='googleSignInFunc' else 'manager_map.json')).read_text())
    statements=[e for e in entries if e['kind']=='statement']
    decisions=[e for e in entries if e['kind']=='decision']
    arms=[e for e in entries if e['kind']=='switch-arm']
    metrics={m['metricsId']:m['value'] for m in fn['metrics']}
    start=fn['codeSpan']['start']['line'];end=fn['codeSpan']['end']['line']
    decision_hits=sum(counts['decisions'].get(e['id'],{}).get(v,0)>0 for e in decisions for v in ['true','false'])
    arm_hits=sum(counts['arms'].get(e['id'],0)>0 for e in arms)
    result[short]={'file':record['path'],'start':start,'end':end,'metrics':metrics,'cognitive':cognitive[name],
        'baseline':lcov('baseline_lcov.info',record['path'],start,end),
        'final':lcov('final_lcov.info',record['path'],start,end),
        'statements':[sum(counts['statements'].get(e['id'],0)>0 for e in statements),len(statements)],
        'boolean_decisions':[decision_hits,2*len(decisions)],'switch_arms':[arm_hits,len(arms)],
        'explicit_branches':[decision_hits+arm_hits,2*len(decisions)+len(arms)]}
(root/'coverage_summary.json').write_text(json.dumps({'functions':result,'counts':counts},indent=2,ensure_ascii=False),encoding='utf-8')
def ratio(value):
    a,b=value
    return f'{a}/{b} ({100*a/b:.1f} %)' if b else 'netaikoma'
rows=''.join('<tr>'+''.join(f'<td>{html.escape(str(v))}</td>' for v in [name,v['metrics']['cyclomatic-complexity'],v['cognitive'],v['metrics']['maintainability-index'],ratio(v['statements']),ratio(v['explicit_branches']),ratio(v['final']['lines'])])+'</tr>' for name,v in result.items())
body=f'''<!doctype html><html lang="lt"><meta charset="utf-8"><title>Edo LD2 matavimų rezultatai</title>
<style>body{{font:18px/1.5 system-ui;margin:38px;color:#202a36;max-width:1300px}}h1,h2{{font-weight:500}}table{{border-collapse:collapse;width:100%;font-size:16px}}td,th{{text-align:left;border:1px solid #ccd3db;padding:12px}}th{{background:#eff3f7}}pre{{background:#f4f6f8;padding:20px;white-space:pre-wrap;font-size:14px}}a{{color:#175abe}}</style>
<h1>MusicReal · Edo dalis · 2026-10-26</h1><p>Versija d90e75ae77d128f895771bfc709856d50ddaf8d6 · Flutter 3.44.9 · Dart 3.12.2 · Windows</p>
<h2>1. Metrikos ir tikras vykdymo padengimas</h2><table><tr><th>Funkcija</th><th>Ciklomatinis</th><th>Kognityvinis</th><th>MI</th><th>Sakiniai (AST)</th><th>Aiškių šakų baigtys</th><th>Eilutės (LCOV)</th></tr>{rows}</table>
<p>Skaičiai automatiškai nuskaityti iš DCL, cognitive_complexity, LCOV ir AST skaitiklių. Naršyklės rezultatai pateikiami atskirai; ši lentelė rodo VM paleidimą.</p>
<h2>2. Testų rezultatai</h2><p>LD1: 15 PASS, 5 FAIL. LD2 pagrindinis rinkinys: 15 PASS. Atskirai R01–R04: 4 FAIL, esamos programos klaidų apdorojimo spragos.</p>
<p>G05–G06 fiksuoja žemo lygio išimčių perdavimą. Tai neįrodo, kad UI tinkamai apdoroja klaidą – tai tikrina atskiri regresijos testai.</p>
<p><a href="metrics_html/index.html">Originali Dart Code Linter ataskaita</a> · <a href="tests.html">Vykdymo žurnalai</a></p>
</html>'''
(root/'index.html').write_text(body,encoding='utf-8')
logs=['final_tests.log','known_defects.log','analysis.log','web_chrome.log']
(root/'tests.html').write_text('<!doctype html><meta charset="utf-8"><title>Edo testų žurnalai</title><style>body{font:16px system-ui;margin:35px}pre{white-space:pre-wrap;font:14px/1.45 monospace;background:#f3f5f7;padding:20px}</style><h1>Flutter testų ir analizės rezultatai</h1>'+''.join('<h2>'+n+'</h2><pre>'+html.escape((root/n).read_text(encoding='utf-8-sig'))+'</pre>' for n in logs if (root/n).exists()),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
