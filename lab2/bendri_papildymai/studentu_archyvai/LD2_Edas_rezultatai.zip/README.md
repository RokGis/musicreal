# MusicReal LD2 – Edo dalis

Data: 2026-10-26. Versija: `d90e75ae77d128f895771bfc709856d50ddaf8d6`.
Flutter 3.44.9, Dart 3.12.2, Windows.

Analizuojamos tikros funkcijos:
- `lib/auth/firebase_auth/google_auth.dart`: `googleSignInFunc()`;
- `lib/auth/firebase_auth/firebase_auth_manager.dart`: `FirebaseAuthManager._signInOrCreateAccount()`.

Programos kodas galutiniame rezultate nepakeistas. Testai įrašyti į `test/ld2_edas`.
Jie naudoja projekte jau esančius `test/mantas/support` platformos pakaitalus.
Jų kopija pateikta `existing_support`; atkuriant darbą geriausia naudoti nurodytą viso projekto commit.
Jokie tikri Google ar Firebase naudotojai nekuriami.

## Paleidimas

Projekto šaknyje, Flutter ir Dart turint PATH:

```powershell
flutter pub get
flutter analyze --no-pub test/ld2_edas
flutter test --no-pub test/ld2_edas/google_sign_in_test.dart test/ld2_edas/auth_manager_test.dart test/ld2_edas/auth_integration_test.dart --coverage --branch-coverage --coverage-path final_lcov.info -r expanded
flutter test --no-pub test/ld2_edas/known_defects_test.dart -r expanded
flutter test --no-pub test/mantas/authentication_test.dart --coverage --branch-coverage --coverage-path baseline_lcov.info -r expanded
```

Pagrindinis rinkinys: **15 PASS** (G01–G06, M01–M08, I01).
Atskiras R01–R04 rinkinys: **4 FAIL** – fiksuoja esamas programos klaidas.
LD1 autentifikacijos rinkinys: **15 PASS, 5 FAIL**. Dalis jo kritimų susiję su Facebook, kurio šios dvi Edo funkcijos neapima.
Viso katalogo paleidimas dėl regresijos testų bus nesėkmingas. Tai sąmoningai neslepiama.

`google_web_test.dart` G07–G09 skirtas tik naršyklei (`@TestOn('browser')`).
Testas sukompiliuotas web testų įkėlimui, tačiau sėkmingas vykdymas šioje aplinkoje nepatvirtintas:
Brave ir Chrome paleidimas liko `loading` / `Running test suite` būsenoje ir buvo nutrauktas;
Edge nepasileido po trijų paties Flutter bandymų. Tai aplinkos ribojimas, ne trys praėję testai ir ne patvirtintas programos defektas.
Originalūs žurnalai išsaugoti. Kitos aplinkos pakartojimui:

```powershell
$env:CHROME_EXECUTABLE = 'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe'
flutter test --no-pub --platform chrome --timeout=60s test/ld2_edas/google_web_test.dart -r expanded
```

## Pirmasis variantas ir pataisymai

`initial_tests/` – pirmas nepataisytas pagrindinių testų ir pagalbininko variantas.
Pirmas paleidimas nekompiliavo rinkinio: bandyta sukurti abstrakčią `UserCredentialPlatform`,
o parametrizuoto testo ID naudojo netaisyklingą `number++.toString()` sintaksę.
Pataisos: sukurtas mažas `EmptyUserCredential` poklasis; skaitiklio didinimas iškeltas į kitą sakinį.
Pirmą kartą pataisius tik abstrakčią klasę liko sintaksės klaida (`second_run.log`).
Po abiejų pataisų visi 15 pagrindinių testų praėjo.
Analizatorius dar rado šešis importų perspėjimus / pranešimus; jie pašalinti.
Galutinis rezultatas: `No issues found!`.

Web testai pridėti po pirmojo VM rinkinio; jų pirmasis variantas išsaugotas atskirai tame pačiame kataloge ir nelaikomas pirmojo VM paleidimo dalimi.

## Metrikos

```powershell
dart pub global activate dart_code_linter 4.4.2
dart pub global activate cognitive_complexity 0.3.0
dart pub global run dart_code_linter:metrics analyze lib/auth/firebase_auth --reporter=json --json-path=metrics.json --no-fatal-warnings
dart pub global run dart_code_linter:metrics analyze lib/auth/firebase_auth --reporter=html --output-directory=metrics_html --no-fatal-warnings
dart pub global run cognitive_complexity:cognitive_complexity lib/auth/firebase_auth/google_auth.dart --format=json
dart pub global run cognitive_complexity:cognitive_complexity lib/auth/firebase_auth/firebase_auth_manager.dart --format=json
```

| Funkcija | Ciklomatinis | Kognityvinis | MI | DCL LOC | DCL SLOC |
|---|---:|---:|---:|---:|---:|
| googleSignInFunc | 4 | 2 | 62 | 15 | 11 |
| _signInOrCreateAccount | 5 | 5 | 54 | 30 | 22 |

DCL pirmam rezultatui skaičiuoja 1 bazę + 2 if + 1 `?.`.
Antram: 1 bazę + if + `?.` + `?:` + catch.
Ši DCL versija neprideda taškų už naujesnę switch išraišką. Tai įrankio rezultatas su apribojimu, ne rankinis visų galimų šakų suskaičiavimas.
Kognityvinis: Google 2 if po 1; manager if 1 + ternary 1 + catch 1 + switch catch viduje 2 = 5.

MI naudojama ta pati formulė kaip Manto dalyje:
`ceil(clamp((171 - 5.2 ln(max(1,V)) - 0.23 CC - 16.2 ln(max(1,SLOC))) / 171 * 100, 0, 100))`.
V naudojama tik įrankio viduje MI skaičiavimui; atskira Halstead užduotis neatliekama.
Tai dviejų funkcijų MI, ne viso projekto įvertinimas. DCL LOC ir SLOC apibrėžtys nėra automatiškai viso projekto fiziniai LOC / CLOC / NCLOC.

Dokumentacija:
- https://dcl.apps.bancolombia.com/docs/metrics/cyclomatic-complexity
- https://dcl.apps.bancolombia.com/docs/metrics/maintainability-index
- https://pub.dev/packages/cognitive_complexity/versions/0.3.0

## Padengimas

| Rodiklis (VM, įprastas rinkinys) | googleSignInFunc | _signInOrCreateAccount |
|---|---:|---:|
| LD1 LCOV eilutės | 6/7 | 13/13 |
| LD2 LCOV eilutės | 6/7 | 13/13 |
| LD1 VM šakų taškai | 2/4 | 5/7 |
| LD2 VM šakų taškai | 3/4 | 7/7 |
| AST sakiniai | 7/8 | 9/9 |
| if / ternary true ir false baigtys | 3/4 | 4/4 |
| switch išraiškos pasirinkimai | netaikoma | 3/3 |
| Aiškių šakų baigtys (if / ternary + switch) | 3/4 | 7/7 |

Google nepadengtas originalo 10 eilutės web `signInWithPopup` sakinys ir `kIsWeb == true` baigtis.
Naršyklės testai neįtraukti į padengimą, nes jų vykdymas nepatvirtintas.
Eilučių padengimas nuo LD1 nepadidėjo, bet nauji testai pasiekė papildomas VM šakų baigtis.
VM BRDA taškai nėra tas pats, kas savarankiškai suskaičiuoti sprendimai.

`instrument.dart` naudoja analyzer AST per DCL paketo priklausomybes.
Skaičiuojami pasirinktų funkcijų vykdomi Statement mazgai be Block (8 ir 9),
keturi if / ternary sprendimai ir trys manager switch pasirinkimai.
Try sakinys įtraukiamas; catch nėra atskiras boolean sprendimas, tačiau jo kūno sakiniai skaičiuojami.
Į išraišką įterptas skaitiklis išsaugo jos reikšmę ir nedubliuoja vykdymo.
Tai ne MC/DC, ne visų išimčių ar visų kelių padengimas; implicitiniai `?.` operatoriaus keliai atskirai nematuojami.

Skaitikliui paslėpus Dart tipo susiaurinimą, instrumentuotame variante pridedamas `!` prie `auth`
po originalios ankstyvo grįžimo patikros ir prie `userCredential` originalios ternary ne-null šakoje.
Originalus kodas atkuriamas `finally` bloke. Instrumentuotas rinkinys taip pat davė 15 PASS.
`google_map.json`, `manager_map.json` ir `coverage_summary.json` leidžia patikrinti kiekvieną skaitiklį.

Pakartojimas Windows aplinkoje:
```powershell
# run_probe.ps1 pradžioje prireikus pakeisti Dart, Flutter ir package_config.json vietas.
.\run_probe.ps1 -Repo 'C:\kelias\musicreal'
python summarize.py
```

## Ką rodo regresijos testai

- R01: atšaukus Google prisijungimą grąžinamas null, bet nėra pranešimo (SCRUM-165).
- R02: Google SDK PlatformException neapdorojama (SCRUM-166).
- R03: FirebaseAuthException su null message sukelia null patikros klaidą (`e.message!`). Tai papildomas patikimumo radinys, naujas Jira darbas nekurtas.
- R04: profilio Firestore įrašymo išimtis neapdorojama. Firebase sesija jau gali būti sukurta, nors profilio nėra. Tai papildomas registracijos nuoseklumo radinys, naujas Jira darbas nekurtas.

G05 patikrina esamą žemo lygio išimties perdavimą, M03 – esamą null grąžinimą.
Jie nėra įrodymas, kad AC6 tenkinamas; tam yra R01 ir R02.
M04 dirbtinai sukuria credential be user, kad patikrintų gynybinę kodo šaką; tai ne teiginys, kad tikras SDK normaliai grąžina tokį rezultatą.

## Testų kokybė ir ribos

G01–G06 tiesiogiai kviečia Google funkciją. M01–M08 privatų manager metodą pasiekia per viešą `signInWithGoogle`, nekeisdami jo prieigos.
I01 paleidžia tikrą prisijungimo ekraną, manager, Google helperį, profilio sukūrimą ir tikrą profilio ekraną;
Home maršrutas pakeistas žymekliu, o serveriai ir SDK – platformos pakaitalais. Tai komponentų integracija, ne tikras OAuth E2E.

Testai naudoja bendrus pakaitalus ir kiekvieną kartą atkuria globalią būseną.
Pasikartojantys trijų klaidų pranešimų atvejai registruojami kaip trys atskiri testai.
Keli tikrinimai viename teste tikrina tą patį prisijungimo rezultatą, tačiau testai vis tiek priklauso nuo UI tekstų ir SDK platformos sąsajų.
I01 turi 200 ms laukimą dėl esamo GoogleSignIn užklausų eiliškumo – lėtesnėje aplinkoje jis gali būti trapus.
Pakaitalai nepatikrina tikro OAuth lango, tinklo, Firebase saugos taisyklių ir SDK elgsenos įrenginyje.

LD1 testai saugomi tame pačiame projekte, tačiau vien jų buvimas neįrodo, kad jie rašyti žmogaus rankomis.
Todėl pateiktas ankstesnio ir naujo rinkinio palyginimas, o autorystė neprimesta.
Testai parengti šiame Codex pokalbyje. Instrukcijų santrauka ir kilmės duomenys: generation_instructions.txt. Tikslus modelio identifikatorius neišsaugotas.
