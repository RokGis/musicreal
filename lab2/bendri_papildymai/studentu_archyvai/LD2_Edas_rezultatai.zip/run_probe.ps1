param([string]$Repo = 'C:\Users\pedse\Downloads\musicreal', [switch]$Baseline)
$ErrorActionPreference = 'Stop'
$dartExe = 'C:\Users\pedse\sdk\flutter\bin\dart.bat'
$flutterExe = 'C:\Users\pedse\sdk\flutter\bin\flutter.bat'
$packageConfig = 'C:\Users\pedse\AppData\Local\Pub\Cache\global_packages\dart_code_linter\.dart_tool\package_config.json'
Push-Location $Repo
try {
 foreach ($name in @('google_auth','firebase_auth_manager')) {
  $mapName = if ($name -eq 'google_auth') { 'google' } else { 'manager' }
  & $dartExe "--packages=$packageConfig" "$PSScriptRoot\instrument.dart" "lib/auth/firebase_auth/$name.dart" "$PSScriptRoot\$name.instrumented.dart" "$PSScriptRoot\${mapName}_map.json" "$Repo\test\ld2_edas\coverage_probe.dart"
  if ($LASTEXITCODE -ne 0) { throw 'Instrumentavimo klaida' }
  Copy-Item -LiteralPath "lib/auth/firebase_auth/$name.dart" -Destination "$PSScriptRoot\$name.original.dart" -Force
 }
 try {
  foreach ($name in @('google_auth','firebase_auth_manager')) {
   Copy-Item -LiteralPath "$PSScriptRoot\$name.instrumented.dart" -Destination "lib/auth/firebase_auth/$name.dart" -Force
  }
  if ($Baseline) {
   & $flutterExe test --no-pub test/mantas/authentication_test.dart -r expanded *> "$PSScriptRoot\probe_baseline.log"
  } else {
   & $flutterExe test --no-pub test/ld2_edas/google_sign_in_test.dart test/ld2_edas/auth_manager_test.dart test/ld2_edas/auth_integration_test.dart -r expanded *> "$PSScriptRoot\probe_tests.log"
  }
 } finally {
  foreach ($name in @('google_auth','firebase_auth_manager')) {
   Copy-Item -LiteralPath "$PSScriptRoot\$name.original.dart" -Destination "lib/auth/firebase_auth/$name.dart" -Force
  }
 }
} finally { Pop-Location }
