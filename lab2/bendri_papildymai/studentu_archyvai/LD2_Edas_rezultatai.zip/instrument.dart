import 'dart:convert';
import 'dart:io';
import 'package:analyzer/dart/analysis/utilities.dart';
import 'package:analyzer/dart/ast/ast.dart';
import 'package:analyzer/dart/ast/visitor.dart';

class Collector extends RecursiveAstVisitor<void> {
  Collector(this.lineInfo);
  final dynamic lineInfo;
  String? method;
  final edits = <(int, String, int)>[];
  final entries = <Map<String, dynamic>>[];
  String id(AstNode node, String kind) {
    final loc = lineInfo.getLocation(node.offset);
    final key = '$method:$kind:${loc.lineNumber}:${loc.columnNumber}';
    entries.add({'id': key, 'method': method, 'kind': kind,
      'line': loc.lineNumber, 'column': loc.columnNumber, 'source': node.toSource()});
    return key;
  }
  @override
  void visitFunctionDeclaration(FunctionDeclaration node) {
    if (node.name.lexeme != 'googleSignInFunc') return;
    method = node.name.lexeme;
    node.functionExpression.body.accept(this);
    method = null;
  }
  @override
  void visitMethodDeclaration(MethodDeclaration node) {
    if (node.name.lexeme != '_signInOrCreateAccount') return;
    method = node.name.lexeme;
    node.body.accept(this);
    method = null;
  }
  @override
  void visitBlock(Block node) {
    if (method == null) return;
    for (final statement in node.statements) {
      if (statement is! Block) {
        final key = id(statement, 'statement');
        edits.add((statement.offset, "EdasProbe.statement('$key'); ", 0));
      }
    }
    super.visitBlock(node);
  }
  void wrap(Expression expression) {
    final key = id(expression, 'decision');
    edits.add((expression.offset, "EdasProbe.condition('$key', (", 1));
    edits.add((expression.end, '))', 2));
  }
  @override
  void visitIfStatement(IfStatement node) {
    wrap(node.expression);
    super.visitIfStatement(node);
  }
  @override
  void visitConditionalExpression(ConditionalExpression node) {
    wrap(node.condition);
    super.visitConditionalExpression(node);
  }
  @override
  void visitSwitchExpressionCase(SwitchExpressionCase node) {
    final key = id(node, 'switch-arm');
    edits.add((node.expression.offset, "EdasProbe.arm('$key', (", 1));
    edits.add((node.expression.end, '))', 2));
    super.visitSwitchExpressionCase(node);
  }
}

void main(List<String> args) {
  final source = File(args[0]).readAsStringSync();
  final parsed = parseString(content: source, path: args[0]);
  final visitor = Collector(parsed.lineInfo);
  parsed.unit.accept(visitor);
  var result = source;
  visitor.edits.sort((a,b) => a.$1 == b.$1 ? b.$3.compareTo(a.$3) : b.$1.compareTo(a.$1));
  for (final edit in visitor.edits) {
    result = result.replaceRange(edit.$1, edit.$1, edit.$2);
  }
  // Wrapping auth == null hides its promotion; original early return guarantees non-null here.
  result = result.replaceAll('idToken: auth.idToken', 'idToken: auth!.idToken')
      .replaceAll('accessToken: auth.accessToken', 'accessToken: auth!.accessToken')
      .replaceAll('fromUserCredential(userCredential)', 'fromUserCredential(userCredential!)');
  result = "import '${File(args[3]).absolute.uri}';\n$result";
  File(args[1]).writeAsStringSync(result);
  File(args[2]).writeAsStringSync(const JsonEncoder.withIndent('  ').convert(visitor.entries));
  print('${visitor.entries.length} mapped nodes for ${args[0]}');
}
