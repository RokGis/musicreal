import 'file:///C:/Users/pedse/Downloads/musicreal/test/ld2_edas/coverage_probe.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';

final _googleSignIn = GoogleSignIn(scopes: ['profile', 'email']);

Future<UserCredential?> googleSignInFunc() async {
  EdasProbe.statement('googleSignInFunc:statement:8:3'); if (EdasProbe.condition('googleSignInFunc:decision:8:7', (kIsWeb))) {
    // Once signed in, return the UserCredential
    EdasProbe.statement('googleSignInFunc:statement:10:5'); return await FirebaseAuth.instance.signInWithPopup(GoogleAuthProvider());
  }

  EdasProbe.statement('googleSignInFunc:statement:13:3'); await signOutWithGoogle().catchError((_) => null);
  EdasProbe.statement('googleSignInFunc:statement:14:3'); final auth = await (await _googleSignIn.signIn())?.authentication;
  EdasProbe.statement('googleSignInFunc:statement:15:3'); if (EdasProbe.condition('googleSignInFunc:decision:15:7', (auth == null))) {
    EdasProbe.statement('googleSignInFunc:statement:16:5'); return null;
  }
  EdasProbe.statement('googleSignInFunc:statement:18:3'); final credential = GoogleAuthProvider.credential(
      idToken: auth!.idToken, accessToken: auth!.accessToken);
  EdasProbe.statement('googleSignInFunc:statement:20:3'); return FirebaseAuth.instance.signInWithCredential(credential);
}

Future signOutWithGoogle() => _googleSignIn.signOut();
