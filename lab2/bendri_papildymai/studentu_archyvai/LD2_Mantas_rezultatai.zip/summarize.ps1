$ErrorActionPreference = 'Stop'
$labOut = $PSScriptRoot
$map = Get-Content "$labOut\coverage_map.json" -Raw | ConvertFrom-Json
$statementHits = @{}
$decisionHits = @{}
foreach ($logName in @('probe_tests.log', 'probe_demo.log')) {
  foreach ($line in Get-Content "$labOut\$logName") {
    if ($line -match 'LD2_PROBE=(\{.*\})') {
      $probe = $Matches[1] | ConvertFrom-Json
      foreach ($prop in $probe.statements.PSObject.Properties) {
        $statementHits[$prop.Name] = [int]$statementHits[$prop.Name] + [int]$prop.Value
      }
      foreach ($prop in $probe.decisions.PSObject.Properties) {
        if (!$decisionHits.ContainsKey($prop.Name)) { $decisionHits[$prop.Name] = @{true=0;false=0} }
        $decisionHits[$prop.Name]['true'] += [int]$prop.Value.true
        $decisionHits[$prop.Name]['false'] += [int]$prop.Value.false
      }
    }
  }
}

function Get-TargetLcov([string]$Path) {
  $active = $false
  $lines = @{}
  $branches = @{}
  foreach ($line in Get-Content $Path) {
    if ($line.StartsWith('SF:')) { $active = $line -match '[/\\]pages[/\\]post[/\\]post_widget\.dart$' }
    elseif ($active -and $line -match '^DA:(\d+),(\d+)') { $lines[[int]$Matches[1]] = [int]$Matches[2] }
    elseif ($active -and $line -match '^BRDA:(\d+),([^,]+),([^,]+),([^,]+)') {
      $branches["$($Matches[1]),$($Matches[2]),$($Matches[3])"] = @{line=[int]$Matches[1];hits=if ($Matches[4] -eq '-') {0} else {[int]$Matches[4]}}
    }
  }
  return @{lines=$lines;branches=$branches}
}

$lcov = @{}
foreach ($name in @('baseline', 'final', 'demo')) { $lcov[$name] = Get-TargetLcov "$labOut\${name}_lcov.info" }
$results = @()
foreach ($name in @('_emotionChoice', '_submit')) {
  $statements = @($map | Where-Object { $_.method -eq $name -and $_.kind -eq 'statement' })
  $decisions = @($map | Where-Object { $_.method -eq $name -and $_.kind -eq 'decision' })
  $hitStatements = @($statements | Where-Object { $statementHits[$_.id] -gt 0 }).Count
  $outcomes = 0
  foreach ($entry in $decisions) {
    if ($decisionHits[$entry.id]['true'] -gt 0) { $outcomes++ }
    if ($decisionHits[$entry.id]['false'] -gt 0) { $outcomes++ }
  }
  $start = if ($name -eq '_emotionChoice') {58} else {89}
  $end = if ($name -eq '_emotionChoice') {87} else {156}
  $byRun = @{}
  foreach ($run in @('baseline','final','demo')) {
    $keys = @($lcov[$run].lines.Keys | Where-Object { $_ -ge $start -and $_ -le $end })
    $hit = @($keys | Where-Object { $lcov[$run].lines[$_] -gt 0 }).Count
    $branches = @($lcov[$run].branches.Values | Where-Object { $_.line -ge $start -and $_.line -le $end })
    $byRun[$run] = @{linesHit=$hit;linesTotal=$keys.Count;vmBranchPointsHit=@($branches | Where-Object { $_.hits -gt 0 }).Count;vmBranchPointsTotal=$branches.Count}
  }
  $combinedKeys = @(@($lcov.final.lines.Keys) + @($lcov.demo.lines.Keys) | Where-Object { $_ -ge $start -and $_ -le $end } | Sort-Object -Unique)
  $byRun['combined'] = @{linesHit=@($combinedKeys | Where-Object { $lcov.final.lines[$_] -gt 0 -or $lcov.demo.lines[$_] -gt 0 }).Count;linesTotal=$combinedKeys.Count}
  $results += @{method=$name;statementsHit=$hitStatements;statementsTotal=$statements.Count;decisionsTotal=$decisions.Count;outcomesHit=$outcomes;outcomesTotal=2*$decisions.Count;lineCoverage=$byRun}
}
$details = $map | ForEach-Object {
  $counts = if ($_.kind -eq 'statement') { @{hits=[int]$statementHits[$_.id]} } else { $decisionHits[$_.id] }
  @{id=$_.id;method=$_.method;kind=$_.kind;line=$_.line;column=$_.column;source=$_.source;counts=$counts}
}
@{methods=$results;points=$details} | ConvertTo-Json -Depth 14 | Set-Content "$labOut\coverage_summary.json" -Encoding utf8
$results | ConvertTo-Json -Depth 7

$metricReport = Get-Content "$labOut\metrics.json" -Raw | ConvertFrom-Json
$cognitive = Get-Content "$labOut\cognitive.json" -Raw | ConvertFrom-Json
$record = $metricReport.records | Where-Object { $_.path -like '*post_widget.dart' }
$metricRows = foreach ($name in @('_emotionChoice','_submit')) {
  $method = $record.functions.PSObject.Properties | Where-Object { $_.Name -eq "_PostWidgetState.$name" }
  $cc = ($method.Value.metrics | Where-Object metricsId -eq 'cyclomatic-complexity').value
  $mi = ($method.Value.metrics | Where-Object metricsId -eq 'maintainability-index').value
  $cog = ($cognitive | Where-Object name -eq "_PostWidgetState.$name").score
  "<tr><td>$name()</td><td>$cc</td><td>$cog</td><td>$mi</td></tr>"
}
$coverageRows = foreach ($r in $results) {
  "<tr><td>$($r.method)()</td><td>$($r.statementsHit)/$($r.statementsTotal)</td><td>$($r.outcomesHit)/$($r.outcomesTotal)</td><td>$($r.lineCoverage.baseline.linesHit)/$($r.lineCoverage.baseline.linesTotal)</td><td>$($r.lineCoverage.final.linesHit)/$($r.lineCoverage.final.linesTotal)</td></tr>"
}
$rawCog = [System.Net.WebUtility]::HtmlEncode((Get-Content "$labOut\cognitive.json" -Raw))
$style = 'body{font:16px Segoe UI,sans-serif;max-width:1120px;margin:40px auto;color:#1f2937;background:#fafafa}h1{font-size:28px}h2{margin-top:32px}table{border-collapse:collapse;width:100%;background:white}td,th{padding:13px;border:1px solid #ccd3dc;text-align:left}pre{white-space:pre-wrap;background:#fff;border:1px solid #ccd3dc;padding:18px;font:13px Consolas,monospace}.note{color:#526070}a{color:#1559a0}'
$html = @"
<!doctype html><html lang="lt"><meta charset="utf-8"><title>MusicReal Mantas LD2 matavimai</title><style>$style</style><h1>MusicReal Manto dalis</h1><p>Versija d90e75ae77d128f895771bfc709856d50ddaf8d6 · 2026-10-20 · Flutter 3.44.9 · Dart 3.12.2</p><h2>Sudėtingumo matavimai</h2><p>Dart Code Linter 4.4.2 ir cognitive_complexity 0.3.0. Lentelės reikšmės automatiškai nuskaitytos iš įrankių JSON.</p><table><tr><th>Funkcija</th><th>Ciklomatinis</th><th>Kognityvinis</th><th>Prižiūrimumo indeksas</th></tr>$($metricRows -join '')</table><p><a href="metrics_html/lib/pages/post/post_widget.html">Dart Code Linter HTML ataskaita</a> · <a href="metrics.json">Pradinis DCL JSON</a> · <a href="cognitive.json">Pradinis kognityvinio sudėtingumo JSON</a></p><h2>Kodo padengimas</h2><table><tr><th>Funkcija</th><th>AST sakiniai</th><th>Sprendimų baigtys</th><th>LD1 eilutės</th><th>LD2 eilutės</th></tr>$($coverageRows -join '')</table><p class="note">AST sakiniai ir aiškių if / ?: sprendimų true / false baigtys suskaičiuotos atskiru instrumentuotu paleidimu, sujungus įprastą ir DEMO=true režimus. Tai nėra MC/DC ar visų implicitinių null-aware operatorių padengimas. Eilutės – Flutter LCOV įprastu režimu, nekeistam programos kodui.</p><h2>Testų rezultatai</h2><table><tr><th>Rinkinys</th><th>Rezultatas</th></tr><tr><td>LD1 įkėlimo testai</td><td>14 PASS / 4 FAIL</td></tr><tr><td>LD2 komponentų ir integracinis testas</td><td>16 PASS / 0 FAIL</td></tr><tr><td>LD2 demo režimas</td><td>1 PASS / 0 FAIL</td></tr><tr><td>R01 įrašymo klaidos regresija</td><td>1 FAIL – žinoma reikalavimo spraga</td></tr></table><p><a href="tests.html">Tikri testų vykdymo žurnalai</a> · <a href="coverage_summary.json">Skaitiklių duomenys</a> · <a href="coverage_map.json">AST matavimo taškai</a></p><h2>Kognityvinio įrankio išvestis</h2><pre>$rawCog</pre></html>
"@
Set-Content "$labOut\index.html" $html -Encoding utf8
$logs = foreach ($name in @('analysis.log','final_tests.log','demo_tests.log','regression_tests.log','baseline_tests.log')) {
  '<h2>'+ $name +'</h2><pre>'+[System.Net.WebUtility]::HtmlEncode((Get-Content "$labOut\$name" -Raw))+'</pre>'
}
Set-Content "$labOut\tests.html" ('<!doctype html><html lang="lt"><meta charset="utf-8"><title>Flutter testų rezultatai</title><style>'+$style+'</style><h1>Flutter testų vykdymo žurnalai</h1>'+($logs -join '')+'</html>') -Encoding utf8
