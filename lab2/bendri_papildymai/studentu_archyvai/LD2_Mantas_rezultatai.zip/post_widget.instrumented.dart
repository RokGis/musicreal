import 'file:///C:/Users/pedse/Downloads/musicreal/test/ld2_mantas/coverage_probe.dart';
import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/music_search_sheet_widget.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/demo/demo_data.dart';
import '/index.dart';
import '/ui/app_ui.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'post_model.dart';
export 'post_model.dart';

/// The three emotions a post can carry.
const List<String> kEmotions = [
  'https://static.vecteezy.com/system/resources/thumbnails/059/420/483/small/cool-smiley-face-with-sunglasses-giving-thumbs-up-png.png',
  'https://static.vecteezy.com/system/resources/thumbnails/059/420/444/small/laughing-emoji-with-joyful-expression-and-tears-png.png',
  'https://png.pngtree.com/png-vector/20241102/ourmid/pngtree-crying-sad-emoji-png-image_14216691.png',
];

class PostWidget extends StatefulWidget {
  const PostWidget({super.key});

  static String routeName = 'post';
  static String routePath = '/post';

  @override
  State<PostWidget> createState() => _PostWidgetState();
}

class _PostWidgetState extends State<PostWidget> {
  late PostModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PostModel());

    _model.emojiTextController ??= TextEditingController();
    _model.emojiFocusNode ??= FocusNode();
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  String get _selectedEmotion => _model.emojiTextController.text.trim();

  Widget _emotionChoice(BuildContext context, String url) {
    Ld2Probe.statement('_emotionChoice:statement:59:5'); final isSelected = _selectedEmotion == url;
    Ld2Probe.statement('_emotionChoice:statement:60:5'); return InkWell(
      borderRadius: BorderRadius.circular(14.0),
      onTap: () => safeSetState(() {
        Ld2Probe.statement('_emotionChoice:statement:63:9'); _model.emojiTextController?.text = url;
      }),
      child: Container(
        padding: EdgeInsets.all(8.0),
        decoration: BoxDecoration(
          color: Ld2Probe.condition('_emotionChoice:decision:68:18', (isSelected))
              ? FlutterFlowTheme.of(context).accent1
              : FlutterFlowTheme.of(context).secondaryBackground,
          borderRadius: BorderRadius.circular(14.0),
          border: Border.all(
            color: Ld2Probe.condition('_emotionChoice:decision:73:20', (isSelected))
                ? FlutterFlowTheme.of(context).primary
                : AppUi.border(context),
            width: Ld2Probe.condition('_emotionChoice:decision:76:20', (isSelected)) ? 2.0 : 1.0,
          ),
        ),
        child: AppUi.squareImage(
          context,
          url,
          size: 56.0,
          fallback: Icons.emoji_emotions_outlined,
        ),
      ),
    );
  }

  Future<void> _submit(BuildContext context) async {
    Ld2Probe.statement('_submit:statement:90:5'); final song = FFAppState().CurrentlySelectedSongPost;
    Ld2Probe.statement('_submit:statement:91:5'); final emoji = _selectedEmotion;

    Ld2Probe.statement('_submit:statement:93:5'); if (Ld2Probe.condition('_submit:decision:93:9', (song == ''))) {
      Ld2Probe.statement('_submit:statement:94:7'); _showMessage(context, 'Pick a song before posting.');
      Ld2Probe.statement('_submit:statement:95:7'); return;
    }
    // The emotion buttons store an image URL, not a character.
    Ld2Probe.statement('_submit:statement:98:5'); if (Ld2Probe.condition('_submit:decision:98:9', (emoji.isEmpty || !emoji.startsWith('http') || emoji.length > 500))) {
      Ld2Probe.statement('_submit:statement:99:7'); _showMessage(context, 'Pick an emotion before posting.');
      Ld2Probe.statement('_submit:statement:100:7'); return;
    }

    Ld2Probe.statement('_submit:statement:103:5'); if (Ld2Probe.condition('_submit:decision:103:9', (kDemoMode))) {
      // Demo mode has no Firestore: keep the post in memory so the
      // statistics and the streak react to it.
      Ld2Probe.statement('_submit:statement:106:7'); DemoData.addPost(song, emoji);
      Ld2Probe.statement('_submit:statement:107:7'); FFAppState().CurrentlySelectedSongPost = '';
      Ld2Probe.statement('_submit:statement:108:7'); _showMessage(context, 'Posted. Open Statistics to see it counted.');
      Ld2Probe.statement('_submit:statement:109:7'); context.pushNamed(HomeWidget.routeName);
      Ld2Probe.statement('_submit:statement:110:7'); return;
    }

    Ld2Probe.statement('_submit:statement:113:5'); await UserPostRecord.createDoc(currentUserReference!).set(
      createUserPostRecordData(
        songName: song,
        createdAt: getCurrentTimestamp,
        postUser: currentUserReference,
        emoji: emoji,
      ),
    );

    Ld2Probe.statement('_submit:statement:122:5'); _model.userData = await queryUsersRecordOnce(
      queryBuilder: (usersRecord) => usersRecord.where(
        'uid',
        isEqualTo: currentUserUid,
      ),
      singleRecord: true,
    ).then((s) => s.firstOrNull);

    Ld2Probe.statement('_submit:statement:130:5'); final today = functions.startOfDay(getCurrentTimestamp);
    Ld2Probe.statement('_submit:statement:131:5'); final yesterday = DateTime(today.year, today.month, today.day - 1);
    Ld2Probe.statement('_submit:statement:132:5'); final lastPostDay = Ld2Probe.condition('_submit:decision:132:25', (_model.userData?.lastPostDate == null))
        ? null
        : functions.startOfDay(_model.userData!.lastPostDate!);

    Ld2Probe.statement('_submit:statement:136:5'); if (Ld2Probe.condition('_submit:decision:136:9', (lastPostDay == null || lastPostDay.isBefore(yesterday)))) {
      // First post, or a day was missed: start again.
      Ld2Probe.statement('_submit:statement:138:7'); await currentUserReference!.update(createUsersRecordData(
        streakCount: 1,
        lastPostDate: getCurrentTimestamp,
      ));
    } else if (Ld2Probe.condition('_submit:decision:142:16', ((() { Ld2Probe.statement('_submit:statement:142:12'); return lastPostDay!.isBefore(today); })()))) {
      // Posted yesterday: the streak carries on.
      Ld2Probe.statement('_submit:statement:144:7'); await currentUserReference!.update({
        ...createUsersRecordData(lastPostDate: getCurrentTimestamp),
        ...mapToFirestore({'streak_count': FieldValue.increment(1)}),
      });
    } else {
      // Already posted today: the streak stays as it is.
      Ld2Probe.statement('_submit:statement:150:7'); await currentUserReference!.update(createUsersRecordData(
        lastPostDate: getCurrentTimestamp,
      ));
    }

    Ld2Probe.statement('_submit:statement:155:5'); context.pushNamed(HomeWidget.routeName);
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();
    final song = FFAppState().CurrentlySelectedSongPost;
    final emoji = _selectedEmotion;

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
          automaticallyImplyLeading: false,
          leading: IconButton(
            icon: Icon(
              Icons.arrow_back_rounded,
              color: FlutterFlowTheme.of(context).primaryText,
            ),
            onPressed: () => context.pushNamed(HomeWidget.routeName),
          ),
          title: Text(
            'New post',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  font: GoogleFonts.urbanist(fontWeight: FontWeight.bold),
                  color: FlutterFlowTheme.of(context).primaryText,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 0.0,
        ),
        body: SafeArea(
          top: true,
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(
                AppUi.gutter, 0.0, AppUi.gutter, AppUi.gutter),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AppUi.sectionTitle(context, '1. Choose a song'),
                Expanded(
                  child: AppUi.card(
                    context,
                    padding: EdgeInsets.all(4.0),
                    child: wrapWithModel(
                      model: _model.musicSearchSheetModel,
                      updateCallback: () => safeSetState(() {}),
                      child: MusicSearchSheetWidget(),
                    ),
                  ),
                ),
                AppUi.sectionTitle(context, '2. How do you feel?'),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: kEmotions
                      .map((url) => _emotionChoice(context, url))
                      .toList(),
                ),
                SizedBox(height: AppUi.gap),
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(AppUi.gap),
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                    borderRadius: BorderRadius.circular(12.0),
                    border: Border.all(color: AppUi.border(context)),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        song == ''
                            ? Icons.music_off_outlined
                            : Icons.music_note,
                        size: 18.0,
                        color: song == ''
                            ? FlutterFlowTheme.of(context).secondaryText
                            : FlutterFlowTheme.of(context).primary,
                      ),
                      SizedBox(width: 8.0),
                      Expanded(
                        child: Text(
                          song == '' ? 'No song chosen yet' : song,
                          overflow: TextOverflow.ellipsis,
                          style: song == ''
                              ? AppUi.muted(context)
                              : AppUi.body(context),
                        ),
                      ),
                      if (emoji.startsWith('http')) ...[
                        SizedBox(width: 8.0),
                        AppUi.squareImage(
                          context,
                          emoji,
                          size: 28.0,
                          fallback: Icons.emoji_emotions_outlined,
                        ),
                      ],
                    ],
                  ),
                ),
                SizedBox(height: AppUi.gap),
                SizedBox(
                  width: double.infinity,
                  child: FFButtonWidget(
                    onPressed: () => _submit(context),
                    text: 'Post',
                    options: AppUi.primaryButton(context, height: 48.0),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

void _showMessage(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(
        message,
        style: TextStyle(color: FlutterFlowTheme.of(context).primaryText),
      ),
      duration: Duration(milliseconds: 4000),
      backgroundColor: FlutterFlowTheme.of(context).secondary,
    ),
  );
}
