import 'package:flutter_test/flutter_test.dart';
import 'package:project_for_management/app_state.dart';
import 'package:project_for_management/demo/demo_data.dart';
import 'package:project_for_management/pages/post/post_widget.dart';
import 'support.dart';

void main() {
  setUpAll(setUpMusicRealTestEnv);
  tearDownAll(reportCoverageProbe);
  setUp(resetPostEnvironment);

  testWidgets('D01: demo upload updates memory without Firestore writes',
      (tester) async {
    expect(kDemoMode, isTrue, reason: 'Run with --dart-define=DEMO=true');
    final before = DemoData.myLastMonth.length;
    await openPost(tester, emoji: kEmotions.first);
    await submitPost(tester);
    expect(DemoData.myLastMonth.length, before + 1);
    expect(DemoData.myLastMonth.first.songName, testSong);
    expect(DemoData.myLastMonth.first.emoji, kEmotions.first);
    expect(FFAppState().CurrentlySelectedSongPost, isEmpty);
    expect(fakeFirestore.writeLog, isEmpty);
    expect(find.text(routeMarker('Home')), findsOneWidget);
  }, skip: !kDemoMode);
}
