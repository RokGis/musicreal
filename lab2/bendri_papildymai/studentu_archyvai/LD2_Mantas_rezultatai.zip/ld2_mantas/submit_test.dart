import 'package:flutter_test/flutter_test.dart';
import 'package:project_for_management/pages/post/post_widget.dart';
import 'support.dart';

void main() {
  setUpAll(setUpMusicRealTestEnv);
  tearDownAll(reportCoverageProbe);
  setUp(resetPostEnvironment);

  testWidgets('S01: no song blocks the upload before any write',
      (tester) async {
    await openPost(tester, song: '', emoji: kEmotions.first);
    await submitPost(tester);
    expectBlocked();
  });

  for (final input in <(String, String)>[
    ('S02: no emotion', ''),
    ('S03: a non-http emotion', 'invalid'),
    ('S04: an emotion longer than 500 characters', 'http${'a' * 497}'),
  ]) {
    testWidgets('${input.$1} blocks the upload', (tester) async {
      await openPost(tester, emoji: input.$2);
      await submitPost(tester);
      expectBlocked();
    });
  }

  testWidgets('S05: 500-character emotion reaches the save path',
      (tester) async {
    final emoji = 'http${'a' * 496}';
    await openPost(tester, emoji: emoji);
    await submitPost(tester);
    expect(onlyPost()['emoji'], emoji);
    expect(find.text(routeMarker('Home')), findsOneWidget);
  });

  testWidgets('S06: surrounding whitespace is removed from the saved emotion',
      (tester) async {
    await openPost(tester, emoji: '  ${kEmotions.first}  ');
    await submitPost(tester);
    expect(onlyPost()['emoji'], kEmotions.first);
  });

  testWidgets('S07: first post starts a streak of one', (tester) async {
    await openPost(tester, emoji: kEmotions.first);
    await submitPost(tester);
    expect(onlyPost()['song_name'], testSong);
    expect(onlyPost()['post_user'], 'users/$testUid');
    expect(onlyPost()['created_at'], isA<DateTime>());
    expect(storedUser()['streak_count'], 1);
    expect(storedUser()['last_post_date'], isA<DateTime>());
    expect(find.text(routeMarker('Home')), findsOneWidget);
  });

  testWidgets('S08: a missed day resets an existing streak', (tester) async {
    final now = DateTime.now();
    seedUser(
        lastPost: DateTime(now.year, now.month, now.day - 2, 12), streak: 7);
    await openPost(tester, emoji: kEmotions.first);
    await submitPost(tester);
    expect(storedUser()['streak_count'], 1);
    expect(postPaths(), hasLength(1));
  });

  testWidgets('S09: a post yesterday increments the streak', (tester) async {
    final now = DateTime.now();
    seedUser(
        lastPost: DateTime(now.year, now.month, now.day - 1, 12), streak: 7);
    await openPost(tester, emoji: kEmotions.first);
    await submitPost(tester);
    expect(storedUser()['streak_count'], 8);
    expect(postPaths(), hasLength(1));
  });

  testWidgets('S10: another post today keeps the streak unchanged',
      (tester) async {
    seedUser(lastPost: DateTime.now(), streak: 7);
    await openPost(tester, emoji: kEmotions.first);
    await submitPost(tester);
    expect(storedUser()['streak_count'], 7);
    expect(postPaths(), hasLength(1));
  });

  testWidgets('S11: a validation error does not prevent a corrected upload',
      (tester) async {
    final model = await openPost(tester);
    await submitPost(tester);
    expectBlocked();
    await tester.pump(const Duration(seconds: 5));
    await settle(tester);
    model.emojiTextController!.text = kEmotions.first;
    await submitPost(tester);
    expect(postPaths(), hasLength(1));
    expect(find.text(routeMarker('Home')), findsOneWidget);
  });
}
