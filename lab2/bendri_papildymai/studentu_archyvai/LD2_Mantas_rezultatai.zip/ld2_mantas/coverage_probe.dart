import 'dart:convert';

/// Counters used only during the separate instrumented coverage run.
/// Regular tests run against the unchanged production source.
class Ld2Probe {
  static final Map<String, int> statements = {};
  static final Map<String, Map<String, int>> decisions = {};

  static void statement(String id) {
    statements.update(id, (n) => n + 1, ifAbsent: () => 1);
  }

  static bool condition(String id, bool value) {
    final counts = decisions.putIfAbsent(id, () => {'true': 0, 'false': 0});
    counts['$value'] = counts['$value']! + 1;
    return value;
  }

  static void report() {
    print('LD2_PROBE=${jsonEncode({'statements': statements, 'decisions': decisions})}');
  }
}

void reportCoverageProbe() => Ld2Probe.report();
