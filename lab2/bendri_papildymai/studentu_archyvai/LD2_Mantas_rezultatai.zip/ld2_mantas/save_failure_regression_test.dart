import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:project_for_management/pages/post/post_widget.dart';
import 'support.dart';

void main() {
  setUpAll(setUpMusicRealTestEnv);
  setUp(resetPostEnvironment);

  // This deliberately exposes the existing LD1 requirement gap.
  // It is kept separate from the passing component test suite.
  testWidgets(
      'R01: failed save should display feedback and stay on the post page',
      (tester) async {
    await openPost(tester, emoji: kEmotions.first);
    fakeFirestore.failWritesWith = Exception('permission-denied');
    await submitPost(tester);
    expect(postPaths(), isEmpty);
    expect(find.text('New post'), findsOneWidget);
    expect(find.byType(SnackBar), findsOneWidget);
  });
}
