import 'dart:convert';
import 'dart:io';
import 'package:analyzer/dart/analysis/utilities.dart';
import 'package:analyzer/dart/ast/ast.dart';
import 'package:analyzer/dart/ast/visitor.dart';

class Insert {
  Insert(this.offset, this.text, this.priority);
  final int offset;
  final String text;
  final int priority;
}

class Collector extends RecursiveAstVisitor<void> {
  Collector(this.lineInfo);
  final dynamic lineInfo;
  String? method;
  final edits = <Insert>[];
  final entries = <Map<String, dynamic>>[];

  String id(AstNode node, String kind) {
    final loc = lineInfo.getLocation(node.offset);
    final result = '$method:$kind:${loc.lineNumber}:${loc.columnNumber}';
    entries.add({'id': result, 'method': method, 'kind': kind,
      'line': loc.lineNumber, 'column': loc.columnNumber, 'source': node.toSource()});
    return result;
  }

  @override
  void visitMethodDeclaration(MethodDeclaration node) {
    if (!['_emotionChoice', '_submit'].contains(node.name.lexeme)) return;
    method = node.name.lexeme;
    node.body.accept(this);
    method = null;
  }

  @override
  void visitBlock(Block node) {
    if (method == null) {
      super.visitBlock(node);
      return;
    }
    for (final statement in node.statements) {
      if (statement is! Block) {
        final key = id(statement, 'statement');
        edits.add(Insert(statement.offset, "Ld2Probe.statement('$key'); ", 0));
      }
    }
    super.visitBlock(node);
  }

  void wrap(Expression expression) {
    final key = id(expression, 'decision');
    edits.add(Insert(expression.offset, "Ld2Probe.condition('$key', (", 1));
    edits.add(Insert(expression.end, '))', 2));
  }

  @override
  void visitIfStatement(IfStatement node) {
    wrap(node.expression);
    // A bare else-if is not a block member, so count it explicitly.
    if (node.parent is IfStatement) {
      final key = id(node, 'statement');
      // Inserting before `else if` would break syntax; count when its condition is evaluated.
      edits.add(Insert(node.expression.offset,
          "(() { Ld2Probe.statement('$key'); return ", 3));
      edits.add(Insert(node.expression.end, '; })()', -1));
    }
    super.visitIfStatement(node);
  }

  @override
  void visitConditionalExpression(ConditionalExpression node) {
    wrap(node.condition);
    super.visitConditionalExpression(node);
  }
}

void main(List<String> args) {
  final source = File(args[0]).readAsStringSync();
  final parsed = parseString(content: source, path: args[0]);
  final visitor = Collector(parsed.lineInfo);
  parsed.unit.accept(visitor);
  var result = source;
  visitor.edits.sort((a, b) {
    final position = b.offset.compareTo(a.offset);
    return position != 0 ? position : b.priority.compareTo(a.priority);
  });
  for (final edit in visitor.edits) {
    result = result.replaceRange(edit.offset, edit.offset, edit.text);
  }
  // The probe hides the previous null-check from Dart's flow analysis.
  // The original else-if is reached only after lastPostDay != null.
  result = result.replaceAll('lastPostDay.isBefore(today)', 'lastPostDay!.isBefore(today)');
  result = "import '${File(args[3]).absolute.uri}';\n$result";
  File(args[1]).writeAsStringSync(result);
  File(args[2]).writeAsStringSync(const JsonEncoder.withIndent('  ').convert(visitor.entries));
  print('Instrumented ${visitor.entries.where((e) => e['kind'] == 'statement').length} statements and ${visitor.entries.where((e) => e['kind'] == 'decision').length} decisions.');
}
