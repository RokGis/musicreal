import 'package:flutter_test/flutter_test.dart';
import 'package:project_for_management/pages/post/post_widget.dart';
import 'support.dart';

void main() {
  setUpAll(setUpMusicRealTestEnv);
  setUp(resetPostEnvironment);

  testWidgets('E01: no emotion selected gives every choice a thin border', (tester) async {
    await openPost(tester);
    for (var i = 0; i < kEmotions.length; i++) {
      expect(borderWidth(tester, i), 1.0);
    }
  });

  testWidgets('E02: tapping an emotion updates the model and its selected style', (tester) async {
    final model = await openPost(tester);
    final initial = choiceDecoration(tester, 0);
    await tapChoice(tester, 0);
    expect(model.emojiTextController!.text, kEmotions[0]);
    expect(borderWidth(tester, 0), 2.0);
    expect(choiceDecoration(tester, 0).color, isNot(initial.color));
    expect(choiceDecoration(tester, 0).border, isNot(initial.border));
  });

  testWidgets('E03: a second choice deselects the first', (tester) async {
    final model = await openPost(tester);
    await tapChoice(tester, 0);
    await tapChoice(tester, 1);
    expect(model.emojiTextController!.text, kEmotions[1]);
    expect(borderWidth(tester, 0), 1.0);
    expect(borderWidth(tester, 1), 2.0);
  });

  testWidgets('E04: tapping the same emotion keeps it selected', (tester) async {
    final model = await openPost(tester);
    await tapChoice(tester, 0);
    await tapChoice(tester, 0);
    expect(model.emojiTextController!.text, kEmotions[0]);
    expect(borderWidth(tester, 0), 2.0);
  });
}
