import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:project_for_management/app_state.dart';
import 'package:project_for_management/auth/base_auth_user_provider.dart' as auth;
import 'package:project_for_management/flutter_flow/flutter_flow_widgets.dart';
import 'package:project_for_management/pages/post/post_model.dart';
import 'package:project_for_management/pages/post/post_widget.dart';

import '../mantas/support/test_env.dart';
export '../mantas/support/test_env.dart';

const testUid = 'ld2-mantas';
const testSong = 'Morning Light';

void resetPostEnvironment() {
  resetMusicRealTestEnv();
  auth.currentUser = TestAuthUser(uid: testUid);
  fakeAuth.signInAs(FakeIdentity(uid: testUid));
  seedUser();
}

void seedUser({DateTime? lastPost, int streak = 0}) {
  fakeFirestore.seed('users/$testUid', {
    'uid': testUid,
    'display_name': 'Mantas',
    'streak_count': streak,
    if (lastPost != null) 'last_post_date': lastPost,
  });
}

Future<PostModel> openPost(WidgetTester tester, {
  String song = testSong,
  String emoji = '',
}) async {
  FFAppState().CurrentlySelectedSongPost = song;
  final model = PostModel()..emojiTextController = TextEditingController(text: emoji);
  await pumpRoutedPage(tester,
    name: PostWidget.routeName,
    path: PostWidget.routePath,
    page: (_) => Provider<PostModel>.value(value: model, child: const PostWidget()),
  );
  return model;
}

Future<void> submitPost(WidgetTester tester) async {
  await tester.tap(find.widgetWithText(FFButtonWidget, 'Post'));
  await settle(tester);
}

List<String> postPaths() => fakeFirestore.docsIn('users/$testUid/userPost');
Map<String, dynamic> onlyPost() => fakeFirestore.data(postPaths().single)!;
Map<String, dynamic> storedUser() => fakeFirestore.data('users/$testUid')!;

final picker = find.byWidgetPredicate((w) =>
    w is Row && w.children.length > 1 && w.children.every((c) => c is InkWell));
Finder choice(int index) => find.descendant(of: picker, matching: find.byType(InkWell)).at(index);
BoxDecoration choiceDecoration(WidgetTester tester, int index) =>
    tester.widget<Container>(find.descendant(of: choice(index), matching: find.byType(Container)).first).decoration! as BoxDecoration;
double borderWidth(WidgetTester tester, int index) =>
    (choiceDecoration(tester, index).border! as Border).top.width;

Future<void> tapChoice(WidgetTester tester, int index) async {
  await tester.tap(choice(index));
  await settle(tester);
}

void expectBlocked() {
  expect(postPaths(), isEmpty);
  expect(fakeFirestore.writeLog, isEmpty);
  expect(find.text('New post'), findsOneWidget);
  expect(find.byType(SnackBar), findsOneWidget);
}
