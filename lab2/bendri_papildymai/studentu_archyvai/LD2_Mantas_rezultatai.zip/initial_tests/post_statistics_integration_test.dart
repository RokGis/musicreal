import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:project_for_management/pages/post/post_widget.dart';
import 'package:project_for_management/statistics/statistics_widget.dart';
import 'support.dart';

void main() {
  setUpAll(setUpMusicRealTestEnv);
  setUp(resetPostEnvironment);

  testWidgets('I01: a saved post appears in the real statistics screen', (tester) async {
    await openPost(tester);
    await tapChoice(tester, 1);
    await submitPost(tester);
    expect(onlyPost()['song_name'], testSong);
    expect(onlyPost()['emoji'], kEmotions[1]);

    await pumpRoutedPage(tester,
      name: StatisticsWidget.routeName,
      path: StatisticsWidget.routePath,
      page: (_) => const StatisticsWidget(),
    );
    expect(find.text(testSong), findsOneWidget);
    final row = find.ancestor(of: find.text(testSong), matching: find.byType(Row));
    expect(find.descendant(of: row, matching: find.byWidgetPredicate((w) =>
      w is Image && w.image is NetworkImage && (w.image as NetworkImage).url == kEmotions[1])), findsWidgets);
    expect(find.descendant(of: row, matching: find.text('1')), findsWidgets);
  });
}
