# MusicReal LD2 Manto dalis

Analizuota `main` versija `d90e75ae77d128f895771bfc709856d50ddaf8d6`.
Aplinka: Flutter 3.44.9, Dart 3.12.2, Windows.
Programos failas `lib/pages/post/post_widget.dart` galutiniame rezultate nepakeistas.

## Testai

Testai yra projekto `test/ld2_mantas` kataloge ir naudoja esamus `test/mantas/support` pakaitalus.
Visos komandos vykdomos projekto šaknyje, kai Flutter yra PATH.

```powershell
flutter pub get
flutter analyze --no-pub test/ld2_mantas
flutter test --no-pub test/ld2_mantas/emotion_choice_test.dart test/ld2_mantas/submit_test.dart test/ld2_mantas/post_statistics_integration_test.dart --coverage --branch-coverage --coverage-path final_lcov.info -r expanded
flutter test --no-pub test/ld2_mantas/demo_submit_test.dart --dart-define=DEMO=true --coverage --branch-coverage --coverage-path demo_lcov.info -r expanded
flutter test --no-pub test/ld2_mantas/save_failure_regression_test.dart -r expanded
```

Pagrindinis rinkinys: 16 PASS. Demo: 1 PASS. R01: 1 FAIL, atskirai išskirta žinoma nesėkmingo įrašymo spraga.
R01 nepaverstas sėkmingu patikrinant klaidingą programos elgesį. Testas tikisi naudotojui rodomo pranešimo ir atskleidžia, kad jo nėra.
Todėl paleidus visą `test/ld2_mantas` be filtravimo bendras rezultatas bus nesėkmingas; demo testas be DEMO=true praleidžiamas.

Tai Flutter komponentų (widget) testai; I01 apima kelis tikrus komponentus, bet testinius Firebase pakaitalus, o ne Firebase serverį.

## Metrikos

```powershell
dart pub global activate dart_code_linter 4.4.2
dart pub global activate cognitive_complexity 0.3.0
dart pub global run dart_code_linter:metrics analyze lib/pages/post --reporter=json --json-path=metrics.json --no-fatal-warnings
dart pub global run dart_code_linter:metrics analyze lib/pages/post --reporter=html --output-directory=metrics_html --no-fatal-warnings
dart pub global run cognitive_complexity:cognitive_complexity lib/pages/post/post_widget.dart --format=json
```

`_emotionChoice`: ciklomatinis 5, kognityvinis 3, MI 50.
`_submit`: ciklomatinis 11, kognityvinis 9, MI 41.
MI yra įrankio 0–100 skalė su ceil ir clamp. Formulė pateikta ataskaitoje; tai metodų, ne viso projekto MI.

## Padengimo metodika

`baseline_lcov.info`: tik ankstesnis `test/mantas/post_emotion_test.dart` rinkinys (14 PASS, 4 FAIL).
`final_lcov.info`: 16 naujų įprasto režimo testų.
`demo_lcov.info`: atskiras DEMO=true paleidimas.

Eilučių skaičiai pasirinktuose metoduose:

| Metodas | LD1 | LD2 įprastas | LD2 įprastas + demo |
|---|---:|---:|---:|
| `_emotionChoice` | 16/16 | 16/16 | 16/16 |
| `_submit` | 21/33 | 29/33 | 33/33 |

LCOV eilučių negalima tiesiog vadinti sakinių padengimu. Todėl papildomai sukurtas AST instrumentavimo įrankis `instrument.dart`.
Jis analizuoja originalų failą su `package:analyzer`, tik dviejų pasirinktų metodų AST `Statement` mazgams (be `Block`) prideda vykdymo skaitiklius ir registruoja `if` bei `?:` sprendimų bool rezultatus.
Įtraukiami vidiniai callback sakiniai. Else-if sakinys registruojamas įvertinus jo sąlygą. Iš viso 28 sakiniai ir 9 sprendimai.

Skaitikliai yra `test/ld2_mantas/coverage_probe.dart`. Įrankis įterpia absoliutų šio failo importą tik į atskirai generuojamą instrumentuotą variantą.
Kadangi sąlygos wrapper panaikina Dart statinį nullable tipo susiaurinimą, else-if instrumentuotame variante įterptas `!`, kur non-null jau garantuoja originali ankstesnė sąlyga. Originalus valdymo elgesys išlaikomas.

Prieš instrumentuotą paleidimą originalus failas nukopijuotas į `post_widget.original.dart`; po paleidimų atkurtas `finally` bloke. Originalo ir HEAD Git objekto hash abiem atvejais `a214cd7d207cb7d86ed321e98fab30c46effe348`.
Instrumentuotas rinkinys taip pat davė 16 + 1 PASS. `probe_tests.log` ir `probe_demo.log` turi tikrus JSON skaitiklius.
`coverage_map.json` nurodo originalaus failo eilutes ir AST mazgus; `coverage_summary.json` – jų vykdymo duomenis. `summarize.ps1` automatiškai apjungia žurnalus.

Pakartotiniam instrumentavimui reikia DCL globalios instaliacijos `package_config.json` ir įrankio argumentų:

```text
dart --packages=<DCL global_packages/dart_code_linter/.dart_tool/package_config.json> instrument.dart <originalus post_widget.dart> <instrumentuoto failo kelias> <coverage_map.json> <coverage_probe.dart absoliutus kelias>
```

Instrumentuotą failą laikinai įdėjus į originalo vietą paleidžiamos tos pačios įprasto ir demo režimų komandos be LCOV. Originalas visada atkuriamas `finally` bloke. Programos loginiai pakeitimai nedaromi.

Sakinių ir aiškių sprendimų baigčių rezultatai, apjungus režimus: `_emotionChoice` 3/3 ir 6/6; `_submit` 25/25 ir 12/12.
Aiškių sąlyginių išsišakojimų baigtys čia sutampa su sprendimų baigtimis. Tai nėra MC/DC, visų kelių, exception-flow ar kiekvieno implicitinio null-aware ir short-circuit operatoriaus baigčių padengimas.
Flutter VM šakų taškai įprastu režimu atskirai: 2/2 ir 8/9. Jie netapatinami su šio įrankio sprendimų skaičiumi.

## Rezultatų failai

`index.html` – automatiškai iš matavimo JSON ir skaitiklių sudaryta santrauka.
`metrics_html/` – originali DCL HTML ataskaita.
`tests.html` – nepakeistų vykdymo žurnalų peržiūra naršyklėje.
`evidence/` – ekrano kopijos.

Testai parengti šiame Codex pokalbyje. Instrukcijų santrauka ir kilmės duomenys: generation_instructions.txt. Tikslus modelio identifikatorius neišsaugotas.
